<div>
    <div class="row">
        <div class="col-12 mt-5" mx-auto>
            <img src="img/logo.png" width="100%" class="img-fluid">
        </div>
    </div>
</div>
<div>
    <div class="row" mx-auto>
        <div class="col-12 mt-3 ">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul class="navbar-nav ml-auto mr-auto mt-0">
                        <li class="nav-item active">
                            <a class="nav-link" href="add.php">Add Item <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="edit.php" tabindex="-1" aria-disabled="true">Edit Item</a>
                        </li>

                        <li class="nav-item active">
                            <a class="nav-link" href="#" tabindex="-1" aria-disabled="true">Statistic</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">My Account</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">My Cart</a>
                                <a class="dropdown-item" href="#">Change Password</a>
                                <div class="dropdown-divider"></div>
                                <a href="server.php?logout='1'" class="dropdown-item">logout</a>
                            </div>
                        </li>

                        <li>
                            <img src="img/dp.jpg" style="width: 50px; height: 50px; border-radius:50px;">
                        </li>
                        <li>
                            <a class="nav-link active">Yasiru Sandeeptha</a>
                        </li>

                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>